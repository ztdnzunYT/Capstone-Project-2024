# Import necessary modules
import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Define screen dimensions for start and game screens
START_SCREEN_WIDTH = 600  # Start screen width
START_SCREEN_HEIGHT = int(START_SCREEN_WIDTH * (38 / 32))  # Start screen height with aspect ratio 32:38

GAME_SCREEN_WIDTH = 800  # Game screen width
GAME_SCREEN_HEIGHT = int(GAME_SCREEN_WIDTH * (3 / 4))  # Game screen height with aspect ratio 3:4

# Set up the display window
screen = pygame.display.set_mode((START_SCREEN_WIDTH, START_SCREEN_HEIGHT))
pygame.display.set_caption("EPIC PICKLE JUMP!")  # Set window title

# Define colors for graphics
SKY_COLOR = (135, 206, 235)  # Sky blue
GRASS_COLOR = (34, 139, 34)  # Grass green
WHITE = (255, 255, 255)  # White color
BLACK = (0, 0, 0)  # Black color
GREEN = (0, 255, 0)  # Green color

# Set up physics and frame rate
clock = pygame.time.Clock()
FPS = 60  # Frames per second
GRAVITY = 0.5  # Gravity value
JUMP_STRENGTH = -15  # Jump force
background_scroll_speed = 5  # Background scrolling speed

# Pickle character settings
pickle_width, pickle_height = 40, 50  # Dimensions of the pickle
ground_level = GAME_SCREEN_HEIGHT - 100  # Ground position
pickle_x, pickle_y = 100, ground_level - pickle_height  # Initial position of pickle
pickle_velocity_y = 0  # Vertical velocity of pickle
on_ground = True  # Is pickle on the ground?
facing_right = True  # Direction pickle is facing
pickle_lives = 3  # Number of lives
pickle_flicker_timer = 0  # Timer for invincibility after getting hit
FLICKER_DURATION = 120  # Flicker duration in frames
pickle_speed = 5  # Speed of pickle movement

# Laser settings
laser_speed = 10  # Speed of lasers fired by pickle
lasers = []  # List to store pickle's lasers
burger_lasers = []  # List to store lasers fired by enemies

# Game stats
score = 0  # Player's score
burgers_hit = 0  # Number of burgers hit
next_burger_boss_spawn = 2500  # Score required for next boss spawn
burger_bosses_defeated = 0  # Number of defeated bosses
burger_laser_offset_y = 20  # Offset for burger boss lasers

# Burger enemy settings
burger_speed = 2  # Speed of burgers
burgers = []  # List to store burger enemies
burger_spawn_interval_min = 150  # Minimum spawn interval for burgers
burger_spawn_interval_max = 300  # Maximum spawn interval for burgers
burger_timer = random.randint(burger_spawn_interval_min, burger_spawn_interval_max)  # Burger spawn timer
max_burgers = 5  # Maximum number of burgers on screen

# Hotdog enemy settings
hotdog_width, hotdog_height = 80, 80  # Dimensions of hotdogs
hotdog_jump_strength = JUMP_STRENGTH  # Jump strength for hotdogs
hotdog_speed = 2  # Speed of hotdogs
hotdog_timer = random.randint(200, 400)  # Hotdog spawn timer
max_hotdogs = 3  # Maximum number of hotdogs on screen
hotdogs = []  # List to store hotdogs

# Load and scale sprites for burger boss and other assets
burger_boss_sprite = pygame.image.load("sprites/burger.boss.png").convert_alpha()
burger_boss_sprite = pygame.transform.scale(burger_boss_sprite, (150, 150))

# Burger boss settings
burger_bosses = []  # List of active burger bosses
burger_boss_speed = 1.5  # Speed of burger boss
burger_boss_health = 6  # Health of burger boss
burger_boss_active = False  # Is a boss active?
burger_boss_y_offset = 20  # Offset for boss vertical position
burger_boss_y = ground_level - burger_boss_sprite.get_height() + burger_boss_y_offset  # Boss y-position

# Load font for text rendering
font = pygame.font.Font(None, 36)  # Font for small text
start_font = pygame.font.Font(None, 72)  # Font for start screen

# Load sprites for characters and objects
burger_sprite = pygame.image.load("sprites/burger.png").convert_alpha()
burger_sprite = pygame.transform.scale(burger_sprite, (50, 50))

hotdog_sprite = pygame.image.load("sprites/hotdog.png").convert_alpha()
hotdog_sprite = pygame.transform.scale(hotdog_sprite, (80, 80))

pickle_sprite = pygame.image.load("sprites/pickle.png").convert_alpha()
pickle_sprite = pygame.transform.scale(pickle_sprite, (pickle_width, pickle_height))

top_bun_sprite = pygame.image.load("sprites/top_bun.png").convert_alpha()
top_bun_sprite = pygame.transform.scale(top_bun_sprite, (50, 25))

you_win_image = pygame.image.load("sprites/you.win.screen.png").convert_alpha()
you_win_image = pygame.transform.scale(you_win_image, (GAME_SCREEN_WIDTH, GAME_SCREEN_HEIGHT))

game_over_image = pygame.image.load("sprites/game.over.screen.png").convert_alpha()
game_over_image = pygame.transform.scale(game_over_image, (GAME_SCREEN_WIDTH, GAME_SCREEN_HEIGHT))

# Adjust start screen image to fit dimensions
start_screen_image = pygame.image.load("sprites/start_screen.png").convert()
start_screen_image = pygame.transform.scale(start_screen_image, (START_SCREEN_WIDTH, START_SCREEN_HEIGHT))

# Tree and cloud settings
TREE_WIDTH, TREE_HEIGHT = 130, 260  # Tree dimensions
TREE_OFFSET_Y = 60  # Vertical offset for trees

# Load and scale tree images
tree_images = [
    pygame.transform.scale(pygame.image.load(f"sprites/tree{i}.png").convert_alpha(), (TREE_WIDTH, TREE_HEIGHT))
    for i in range(1, 9)
]

# Load and scale cloud images
CLOUD_WIDTH, CLOUD_HEIGHT = 150, 90  # Cloud dimensions
cloud_images = [
    pygame.transform.scale(pygame.image.load(f"sprites/cloud{i}.png").convert_alpha(), (CLOUD_WIDTH, CLOUD_HEIGHT))
    for i in range(1, 7)
]

# Remaining sections and function implementations will follow in additional parts due to character constraints.

# Initialize positions for trees and clouds
def initialize_positions(images, min_gap, max_gap, y_range):

    #Initialize positions for a given set of images.
    #:param images: List of images
    #:param min_gap: Minimum gap between consecutive objects
    #:param max_gap: Maximum gap between consecutive objects
    #:param y_range: Vertical range for positioning
    #:return: List of positions as (x, y) tuples

    positions = []
    x = random.randint(0, GAME_SCREEN_WIDTH)
    for _ in images:
        y = random.randint(*y_range)
        positions.append((x, y))
        x += random.randint(min_gap, max_gap)
    return positions

# Set initial positions for trees and clouds
tree_positions = initialize_positions(tree_images, 400, 600, (ground_level - TREE_HEIGHT + TREE_OFFSET_Y, ground_level))
cloud_positions = initialize_positions(cloud_images, 200, 400, (50, 200))

# Draw objects (trees and clouds)
def draw_objects(images, positions, camera_x_change):

    #Draw images on the screen and update their positions for camera movement.
    #:param images: List of images
    #:param positions: List of positions for images
    #:param camera_x_change: Horizontal change for camera movement

    global tree_positions, cloud_positions

    for i, (image, (x, y)) in enumerate(zip(images, positions)):
        x += camera_x_change
        if x + image.get_width() < 0:  # Recycle images when they go off-screen
            x = max(pos[0] for pos in positions) + random.randint(400, 600)
            y = random.randint(50, 200) if image in cloud_images else ground_level - TREE_HEIGHT + TREE_OFFSET_Y
        positions[i] = (x, y)
        screen.blit(image, (x, y))

# Draw the background with trees and clouds
def draw_background(camera_x_change):

    #Draw the sky, grass, trees, and clouds.
    #:param camera_x_change: Horizontal camera movement

    # Sky and grass
    pygame.draw.rect(screen, SKY_COLOR, (0, 0, GAME_SCREEN_WIDTH, GAME_SCREEN_HEIGHT - 100))
    pygame.draw.rect(screen, GRASS_COLOR, (0, GAME_SCREEN_HEIGHT - 100, GAME_SCREEN_WIDTH, 100))
    # Trees and clouds
    draw_objects(cloud_images, cloud_positions, camera_x_change)
    draw_objects(tree_images, tree_positions, camera_x_change)

# Handle Burger Boss interactions
def handle_burger_boss():

    #Manage Burger Boss behavior, movement, and collisions with lasers.

    global burger_boss_active, score, burger_bosses_defeated, lasers

    for boss in burger_bosses:
        if not boss['active']:  # Skip inactive bosses
            continue

        # Move the boss
        boss['x'] -= boss['speed']
        boss_rect = pygame.Rect(boss['x'], boss['y'], boss['sprite'].get_width(), boss['sprite'].get_height())
        screen.blit(boss['sprite'], boss_rect)

        # Draw health bar for the boss
        health_bar_width = 100
        health_bar_height = 10
        health_bar_x = boss_rect.centerx - health_bar_width // 2
        health_bar_y = boss['y'] - 20
        pygame.draw.rect(screen, (255, 0, 0), (health_bar_x, health_bar_y, health_bar_width, health_bar_height))
        pygame.draw.rect(screen, (0, 255, 0), (health_bar_x, health_bar_y, int(health_bar_width * (boss['health'] / boss['max_health'])), health_bar_height))

        # Randomly fire lasers from the boss
        if random.randint(1, 60) == 1:  # Adjust fire rate as needed
            laser_x = boss_rect.left
            laser_y = boss_rect.top + boss_rect.height // 2 + burger_laser_offset_y  # Adjust laser offset
            burger_lasers.append(BurgerLaser(laser_x, laser_y, -10))  # Negative speed for leftward movement

        # Handle collisions with player's lasers
        lasers_to_remove = []
        for laser in lasers:
            if laser.rect.colliderect(boss_rect):
                lasers_to_remove.append(laser)
                boss['health'] -= 1
                if boss['health'] <= 0:
                    boss['active'] = False  # Mark boss as inactive
                    score += 500  # Add score for defeating the boss
                    burger_bosses_defeated += 1  # Increment defeated bosses counter
                    if burger_bosses_defeated == 3:  # Check if player wins
                        you_win_screen()

        # Safely remove lasers that hit the boss
        lasers = [laser for laser in lasers if laser not in lasers_to_remove]

    # Remove inactive bosses
    burger_bosses[:] = [b for b in burger_bosses if b['active']]

# Class for player lasers
class Laser:
    def __init__(self, x, y, speed):

        #Initialize a player laser.
        #:param x: Initial x-coordinate
        #:param y: Initial y-coordinate
        #:param speed: Speed of the laser

        self.rect = pygame.Rect(x, y, 20, 5)  # Define laser dimensions
        self.speed = speed

    def update(self):

        #Update the laser's position.

        self.rect.x += self.speed

    def draw(self, screen):

        #Draw the laser on the screen.
        #:param screen: Pygame screen surface

        pygame.draw.rect(screen, (255, 0, 0), self.rect)  # Red color for lasers

# Class for Burger Boss lasers
class BurgerLaser:
    def __init__(self, x, y, speed):

        #Initialize a laser fired by the Burger Boss.
        #:param x: Initial x-coordinate
        #:param y: Initial y-coordinate
        #:param speed: Speed of the laser

        self.rect = pygame.Rect(x, y, 20, 5)  # Define laser dimensions
        self.speed = speed

    def update(self):

        #Update the laser's position.

        self.rect.x += self.speed

    def draw(self, screen):

        #Draw the laser on the screen.
        #:param screen: Pygame screen surface

        pygame.draw.rect(screen, (128, 0, 128), self.rect)  # Purple color for Burger Boss lasers

# Reset the game state to its initial values
def reset_game_state():

    #Reset all game variables and clear all game object lists.

    global pickle_lives, score, burgers_hit, pickle_x, pickle_y, pickle_velocity_y
    global on_ground, facing_right, next_burger_boss_spawn, burger_bosses, burger_bosses_defeated
    global lasers, burger_lasers, burgers, hotdogs

    # Reset game variables
    pickle_lives = 3
    score = 0
    burgers_hit = 0
    next_burger_boss_spawn = 2500
    pickle_x, pickle_y = 100, ground_level - pickle_height  # Reset pickle position
    pickle_velocity_y = 0  # Reset pickle velocity
    on_ground = True
    facing_right = True
    burger_bosses_defeated = 0

    # Clear object lists
    lasers.clear()
    burger_lasers.clear()
    burgers.clear()
    hotdogs.clear()
    burger_bosses.clear()

# Draw the pickle character on the screen
def draw_pickle():

    #Draw the pickle on the screen with flicker effect when hit.

    if pickle_flicker_timer == 0 or (pickle_flicker_timer // 5) % 2 == 0:
        screen.blit(pickle_sprite, (pickle_x, pickle_y))  # Only draw if not flickering

# Handle player's lasers
def handle_lasers():

    #Update and draw lasers fired by the player, and remove off-screen lasers.

    global lasers
    lasers = [laser for laser in lasers if 0 <= laser.rect.x <= GAME_SCREEN_WIDTH]  # Remove off-screen lasers
    for laser in lasers:
        laser.update()
        laser.draw(screen)

# Handle Burger Boss lasers
def handle_burger_lasers():

    #Update and draw Burger Boss lasers, and check for collisions with the pickle.

    global pickle_lives, pickle_flicker_timer, burger_lasers

    lasers_to_remove = []
    pickle_rect = pygame.Rect(pickle_x, pickle_y, pickle_width, pickle_height)  # Pickle hitbox

    for laser in burger_lasers[:]:
        laser.update()  # Update laser position
        laser.draw(screen)  # Draw laser

        # Check collision with the pickle
        if laser.rect.colliderect(pickle_rect) and pickle_flicker_timer == 0:
            pickle_lives -= 1  # Reduce pickle's lives
            pickle_flicker_timer = FLICKER_DURATION  # Activate flicker timer
            lasers_to_remove.append(laser)  # Mark laser for removal

    # Remove lasers that collided or went off-screen
    burger_lasers = [laser for laser in burger_lasers if laser not in lasers_to_remove and laser.rect.right > 0]

# Handle burger enemies
def handle_burgers():

    #Spawn, update, and draw burgers. Handle collisions with pickle and lasers.

    global burger_timer, score, burgers_hit, pickle_lives, pickle_flicker_timer, burgers, lasers

    burger_timer -= 1
    if burger_timer <= 0 and len(burgers) < max_burgers:  # Spawn new burger if limit not reached
        burger_x = GAME_SCREEN_WIDTH
        burger_y = ground_level - 50
        burgers.append([burger_x, burger_y, False])  # Append burger with position and top-bun state
        burger_timer = random.randint(burger_spawn_interval_min, burger_spawn_interval_max)

    burgers_to_remove = set()
    lasers_to_remove = []

    for i, burger in enumerate(burgers):
        burger_x, burger_y, is_top_bun = burger
        burger_x -= burger_speed  # Move burger to the left
        burgers[i][0] = burger_x

        pickle_rect = pygame.Rect(pickle_x, pickle_y, pickle_width, pickle_height)  # Pickle hitbox
        burger_rect = pygame.Rect(burger_x, burger_y, burger_sprite.get_width(), burger_sprite.get_height())  # Burger hitbox

        # Check collision with pickle
        if pickle_rect.colliderect(burger_rect):
            if pickle_y + pickle_height <= burger_y + 10:  # Check if pickle is jumping on burger
                burgers_to_remove.add(i)  # Mark burger for removal
                burgers[i][2] = True  # Mark as top bun
                score += 100  # Add score
            else:
                if pickle_flicker_timer == 0:  # Damage pickle if not invincible
                    pickle_lives -= 1
                    pickle_flicker_timer = FLICKER_DURATION

        # Check collision with lasers
        for laser in lasers:
            if laser.rect.colliderect(burger_rect):
                burgers_to_remove.add(i)  # Mark burger for removal
                lasers_to_remove.append(laser)  # Mark laser for removal
                score += 100  # Add score

        # Draw burger or top bun
        if burgers[i][2]:
            screen.blit(top_bun_sprite, (burger_x, burger_y))
        else:
            screen.blit(burger_sprite, (burger_x, burger_y))

    # Safely remove burgers and lasers
    burgers = [burger for i, burger in enumerate(burgers) if i not in burgers_to_remove]
    lasers = [laser for laser in lasers if laser not in lasers_to_remove]

# Spawn a hotdog enemy
def spawn_hotdog():

    #Spawn a hotdog if the timer expires and the limit is not reached.

    global hotdog_timer
    hotdog_timer -= 1
    if hotdog_timer <= 0 and len(hotdogs) < max_hotdogs:
        hotdog_x = GAME_SCREEN_WIDTH  # Spawn at the right edge of the screen
        hotdog_y = ground_level - hotdog_sprite.get_height()  # Position on the ground
        hotdogs.append([hotdog_x, hotdog_y, 0])  # Add hotdog with initial velocity
        hotdog_timer = random.randint(200, 400)  # Reset spawn timer

# Handle hotdog enemies
def handle_hotdogs():

    #Update and draw hotdogs. Handle collisions with pickle and lasers.

    global hotdogs, score, pickle_lives, pickle_flicker_timer

    hotdogs_to_remove = []

    for hotdog in hotdogs[:]:
        hotdog_x, hotdog_y, hotdog_velocity_y = hotdog
        if hotdog_y >= ground_level - hotdog_sprite.get_height():  # Check if hotdog hits ground
            hotdog_velocity_y = hotdog_jump_strength  # Make hotdog jump
        else:
            hotdog_velocity_y += GRAVITY  # Apply gravity

        # Update hotdog position
        hotdog_y += hotdog_velocity_y
        hotdog_x -= burger_speed  # Move hotdog to the left
        hotdog[0] = hotdog_x
        hotdog[1] = hotdog_y
        hotdog[2] = hotdog_velocity_y
        screen.blit(hotdog_sprite, (int(hotdog_x), int(hotdog_y)))  # Draw hotdog

        # Check collision with lasers
        for laser in lasers:
            if laser.rect.colliderect(pygame.Rect(hotdog_x, hotdog_y, hotdog_sprite.get_width(), hotdog_sprite.get_height())):
                hotdogs_to_remove.append(hotdog)  # Mark hotdog for removal
                lasers.remove(laser)  # Remove laser
                score += 200  # Add score

        # Check collision with pickle
        pickle_rect = pygame.Rect(pickle_x, pickle_y, pickle_width, pickle_height)
        if pickle_rect.colliderect(pygame.Rect(hotdog_x, hotdog_y, hotdog_sprite.get_width(), hotdog_sprite.get_height())):
            if pickle_flicker_timer == 0:  # Damage pickle if not invincible
                pickle_lives -= 1
                pickle_flicker_timer = FLICKER_DURATION
                hotdogs_to_remove.append(hotdog)  # Mark hotdog for removal

    # Safely remove hotdogs
    hotdogs = [hotdog for hotdog in hotdogs if hotdog not in hotdogs_to_remove]

# Display the game over screen
def game_over_screen():

    #Display the "Game Over" screen and provide a restart button.

    while True:
        # Draw the "Game Over" image
        screen.blit(game_over_image, (0, 0))

        # Create a restart button
        restart_button = pygame.Rect(GAME_SCREEN_WIDTH // 2 - 100, GAME_SCREEN_HEIGHT // 1.5, 200, 50)
        pygame.draw.rect(screen, WHITE, restart_button)  # Draw button
        restart_text = font.render("RESTART", True, BLACK)  # Button text
        restart_text_rect = restart_text.get_rect(center=restart_button.center)
        screen.blit(restart_text, restart_text_rect)

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # Quit game
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:  # Mouse click
                if restart_button.collidepoint(event.pos):  # If restart button is clicked
                    reset_game_state()  # Reset game state
                    return  # Exit the screen and return to game loop

        pygame.display.update()
        clock.tick(FPS)  # Maintain frame rate

# Display the start screen
def start_screen():

    #Display the start screen with a "Play" button.

    global screen
    screen = pygame.display.set_mode((START_SCREEN_WIDTH, START_SCREEN_HEIGHT))  # Set start screen resolution
    reset_game_state()  # Initialize game variables
    start = True
    while start:
        # Draw the start screen image
        screen.blit(start_screen_image, (0, 0))

        # Create the play button
        play_button = pygame.Rect(START_SCREEN_WIDTH // 2 - 100, START_SCREEN_HEIGHT // 2, 200, 50)
        pygame.draw.rect(screen, WHITE, play_button)
        play_text = font.render("Play", True, BLACK)
        play_text_rect = play_text.get_rect(center=play_button.center)
        screen.blit(play_text, play_text_rect)

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # Quit game
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:  # Mouse click
                if play_button.collidepoint(event.pos):  # If play button is clicked
                    start = False  # Exit the start screen loop

        pygame.display.update()
        clock.tick(FPS)  # Maintain frame rate

# Display the "You Win" screen
def you_win_screen():

    #Display the "You Win" screen and provide a restart button.

    while True:
        # Draw the "You Win" image
        screen.blit(you_win_image, (0, 0))

        # Create a restart button
        restart_button = pygame.Rect(GAME_SCREEN_WIDTH // 2 - 100, GAME_SCREEN_HEIGHT // 1.5, 200, 50)
        pygame.draw.rect(screen, WHITE, restart_button)  # Draw button
        restart_text = font.render("RESTART", True, BLACK)  # Button text
        restart_text_rect = restart_text.get_rect(center=restart_button.center)
        screen.blit(restart_text, restart_text_rect)

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # Quit game
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:  # Mouse click
                if restart_button.collidepoint(event.pos):  # If restart button is clicked
                    reset_game_state()  # Reset game state
                    return  # Exit the screen and return to game loop

        pygame.display.update()
        clock.tick(FPS)  # Maintain frame rate

# Generate platforms for the game
def generate_platforms(num_platforms=100):

    #Generate a list of platforms for the game.
    #:param num_platforms: Number of platforms to generate

    global platforms
    platforms = []  # List to store platforms
    min_horizontal_gap = 200  # Minimum horizontal gap between platforms
    max_vertical_gap = 150  # Maximum vertical gap between platforms
    base_y = ground_level - 100  # Base vertical position for platforms

    prev_x = random.randint(0, 100)  # Initial x-coordinate
    for _ in range(num_platforms):
        x = prev_x + random.randint(min_horizontal_gap, min_horizontal_gap + 100)
        y = random.randint(200, base_y)  # Randomize vertical position
        width = random.randint(80, 150)  # Random platform width
        height = 20  # Platform height
        platforms.append(pygame.Rect(x, y, width, height))  # Create platform
        prev_x = x

generate_platforms()  # Generate platforms at game start

# Draw platforms on the screen
def draw_platforms(camera_offset_x):

    #Draw all platforms on the screen with camera adjustments.
    #:param camera_offset_x: Horizontal camera offset

    for platform in platforms:
        platform_moved = platform.move(camera_offset_x, 0)  # Adjust platform position
        pygame.draw.rect(screen, (181, 126, 220), platform_moved)  # Draw platform

# Check collisions between the pickle and platforms
def check_platform_collision(pickle_rect, platforms, camera_x, pickle_velocity_y):
    
    #Check if the pickle is colliding with any platform.
    #:param pickle_rect: Rect object for the pickle
    #:param platforms: List of platform Rect objects
    #:param camera_x: Camera position offset
    #:param pickle_velocity_y: Pickle's vertical velocity
    #:return: The platform Rect object the pickle collides with, or None
    
    step_size = 1  # Step size for collision detection
    for step in range(abs(int(pickle_velocity_y))):  # Iterate for the pickle's velocity
        pickle_rect.y += step_size  # Increment position
        for platform in platforms:
            platform_moved = platform.move(camera_x, 0)  # Adjust for camera movement
            if (pickle_rect.bottom <= platform_moved.top + 5 and
                pickle_rect.bottom >= platform_moved.top and
                pickle_rect.right > platform_moved.left and
                pickle_rect.left < platform_moved.right):  # Check collision
                return platform_moved
    return None  # No collision

# Display the score and remaining lives on the screen
def display_score():

    #Render and display the current score and lives.

    global pickle_lives
    score_text = font.render(f"Score: {score}", True, WHITE)  # Score text
    lives_text = font.render(f"Lives: {pickle_lives}", True, WHITE)  # Lives text
    screen.blit(score_text, (10, 10))  # Draw score
    screen.blit(lives_text, (10, 40))  # Draw lives

# Main game loop
def game_loop():

    #The main game loop. Handles all game logic, rendering, and player interactions.

    global screen, ground_level, burger_boss_active, next_burger_boss_spawn
    global pickle_x, pickle_y, pickle_velocity_y, on_ground, background_scroll_speed, facing_right
    global pickle_lives, pickle_flicker_timer, score, burger_laser_offset_y

    # Set up the game screen dimensions
    screen = pygame.display.set_mode((GAME_SCREEN_WIDTH, GAME_SCREEN_HEIGHT))
    ground_level = GAME_SCREEN_HEIGHT - 100  # Update ground level based on screen height
    camera_x = 0  # Initialize camera position
    running = True  # Main game loop flag

    while running:
        screen.fill(SKY_COLOR)  # Fill the background with sky color
        camera_x_change = 0  # Reset camera movement

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # Quit game
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button
                if facing_right:
                    laser = Laser(pickle_x + pickle_width, pickle_y + pickle_height // 2 - 2, laser_speed)
                else:
                    laser = Laser(pickle_x, pickle_y + pickle_height // 2 - 2, -laser_speed)
                lasers.append(laser)  # Add laser to the list

        # Key handling
        keys = pygame.key.get_pressed()

        # Move pickle left or right
        if keys[pygame.K_a] and pickle_x > 0:  # Move left
            pickle_x -= pickle_speed
            facing_right = False
            camera_x_change = background_scroll_speed
        if keys[pygame.K_d]:  # Move right
            if pickle_x < GAME_SCREEN_WIDTH // 2:
                pickle_x += pickle_speed
            else:
                camera_x_change = -background_scroll_speed
                camera_x -= background_scroll_speed
            facing_right = True

        # Adjust Burger Boss laser firing position numerically
        if keys[pygame.K_1]:  # Set laser offset to a low position
            burger_laser_offset_y = -20
        if keys[pygame.K_2]:  # Set laser offset to the default position
            burger_laser_offset_y = 0
        if keys[pygame.K_3]:  # Set laser offset to a higher position
            burger_laser_offset_y = 20
        if keys[pygame.K_4]:  # Set laser offset to an even higher position
            burger_laser_offset_y = 40

        # Jump action
        pickle_rect = pygame.Rect(pickle_x, pickle_y, pickle_width, pickle_height)
        if keys[pygame.K_SPACE] and on_ground:  # If space is pressed and pickle is on ground
            pickle_velocity_y = JUMP_STRENGTH
            on_ground = False

        # Update pickle position with gravity
        pickle_velocity_y += GRAVITY
        pickle_y += pickle_velocity_y

        # Check for platform collisions
        platform = check_platform_collision(pickle_rect, platforms, camera_x, pickle_velocity_y)
        if platform and pickle_velocity_y >= 0:  # Pickle landed on a platform
            pickle_y = platform.top - pickle_height
            pickle_velocity_y = 0
            on_ground = True
        elif pickle_y + pickle_height >= ground_level:  # Pickle reached the ground
            pickle_y = ground_level - pickle_height
            pickle_velocity_y = 0
            on_ground = True
        else:  # Pickle is in the air
            on_ground = False

        # Draw the background and moving objects
        draw_background(camera_x_change)

        # Reduce flicker timer if active
        if pickle_flicker_timer > 0:
            pickle_flicker_timer -= 1

        # Draw pickle, handle lasers, burgers, and platforms
        draw_pickle()
        handle_lasers()
        handle_burger_lasers()
        handle_burgers()
        draw_platforms(camera_x)
        display_score()

        # Spawn and handle hotdogs
        spawn_hotdog()
        handle_hotdogs()

        # Handle the Burger Boss if active
        if burger_boss_active:
            handle_burger_boss()

        # Spawn a Burger Boss at the designated score
        if score >= next_burger_boss_spawn:
            burger_bosses.append({
                'x': GAME_SCREEN_WIDTH,
                'y': ground_level - burger_boss_sprite.get_height() + burger_boss_y_offset,
                'speed': burger_boss_speed,
                'health': 6,
                'max_health': 6,
                'sprite': burger_boss_sprite,
                'active': True
            })
            burger_boss_active = True  # Activate the boss
            next_burger_boss_spawn += 2500  # Update the next spawn score

        # Check if pickle's lives have run out
        if pickle_lives <= 0:
            game_over_screen()  # Trigger game over screen
            break

        # Update the display and maintain frame rate
        pygame.display.update()
        clock.tick(FPS)

# Run the game
while True:
    
    #Main game flow: Start screen followed by the game loop.

    start_screen()  # Display the start screen
    game_loop()  # Enter the main game loop