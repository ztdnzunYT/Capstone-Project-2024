import pygame
import sys
import os

# DO NOT CHANGE
WIDTH = 1000
HEIGHT = 600
brown = (150, 65, 0)
dark_green = (6, 64, 43)
white = (255, 255, 255)
blue = (173, 216, 230)
fps = 60

# Minimap Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 550
MINIMAP_WIDTH, MINIMAP_HEIGHT = 225, 175

# baseball image
baseball_image = pygame.image.load('Capstone File/Player_Animation/baseball_frame_1.png')
baseball_image = pygame.transform.scale(baseball_image, (23, 23))  # Original size

# Scaling variables
scaling_start_time = 0
scaling_duration = 2500  # Duration for scaling (in milliseconds)
is_scaling = False
scale_factor = 1.0  # Start with a normal size

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Load your minimap image
minimap_image = pygame.image.load("Capstone File\Player_Animation\Top-Down-Field-View.png")
minimap_image = pygame.transform.scale(minimap_image, (MINIMAP_WIDTH, MINIMAP_HEIGHT))

def draw_minimap(screen, minimap_image, baseball_image ,scale_factor):
    # Draw the minimap image
    screen.blit(minimap_image, (SCREEN_WIDTH - MINIMAP_WIDTH - 570, 10))

    # Draw the scaled baseball on the minimap
    scaled_width = int(baseball_image.get_width() * scale_factor)
    scaled_height = int(baseball_image.get_height() * scale_factor)
    scaled_baseball = pygame.transform.scale(baseball_image, (scaled_width, scaled_height))

    # Calculate position to center the baseball on the minimap
    minimap_ball_x = SCREEN_WIDTH - MINIMAP_WIDTH - 570 + MINIMAP_WIDTH // 2 - scaled_width // 2
    minimap_ball_y = 10 + MINIMAP_HEIGHT // 2 - scaled_height // 2

    # Draw the scaled baseball
    screen.blit(scaled_baseball, (minimap_ball_x, minimap_ball_y))

# Ball positions
ball_positions = []

# Pygame window
pygame.init()
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption("B-ball")
timer = pygame.time.Clock()

# The Pitch Button 
throw_button_color = (0, 128, 0)  # Green color for throw button
throw_button_rect = pygame.Rect(800, 500, 150, 50)  # Position and size of the throw button
throw_button_text = "Throw Pitch"
font = pygame.font.Font(None, 36)

# Initial player and baseball positions
player1_x = 177
player1_y = 310
player2_x = 450
player2_y = 238
homeplate_x = 400
homeplate_y = 420
batterbox1_x = 230
batterbox1_y = 420
batterbox2_x = 478
batterbox2_y = 420
sun_x = 850
sun_y = -10
space_down = False

# Baseball variables
baseball_x = 445
baseball_y = 240
baseball_scale = 1.0
pitching = False  # Track if pitching
ball_thrown = False  # Track if ball has been thrown
hit = False  # Track if the ball has been hit
anim = 0
anim_num = 0
delay_time = 0
delay_time2 = 0
pitcher_anim = 0

# Swing Animations
swing_animations = ["Capstone File\Player_Animation\Stance.png", "Capstone File\Player_Animation\Bend.png", "Capstone File\Player_Animation\Swing.png", "Capstone File\Player_Animation\Post_swing.png", "Capstone File\Player_Animation\Stance.png"]
actual_swing = [pygame.transform.smoothscale(pygame.image.load(filename),(340,340)) for filename in swing_animations]
current_image_index = 0
animation_running = False
animation_complete = False
animation_speed = 175

# Pitch Animations
pitch_animations = ["Capstone File\Player_Animation\pitcher_stance2.png", "Capstone File\Player_Animation\pitcher_arm_extend2.png", "Capstone File\Player_Animation\pitcher_release2.png", "Capstone File\Player_Animation\pitcher_aftermath2.png"]
pitcher_throw = [pygame.transform.smoothscale(pygame.image.load(filename),(180,180)) for filename in pitch_animations]
pitcher_animation_running = False
pitcher_animation_complete = False
pitcher_current_image_index = 0
pitcher_animation_speed = 200  # You can adjust this value for the speed
pitcher_last_update_time = pygame.time.get_ticks()

# Post-Hit Animations
post_animations = ['Capstone File\Player_Animation\hit_ball_left.png', 'Capstone File\Player_Animation\hit_ball_center.png', 'Capstone File\Player_Animation\hit_ball_right.png']

# Initial images
batter1 = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation\Stance.png'), (350, 350))
pitcher1 = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation\pitcher_stance2.png'), (100, 100))

# Create rectangles for the batter and baseball
batter_rect = pygame.Rect(player1_x, player1_y, 100, 150)  # Adjust size if needed
baseball_rect = pygame.Rect(baseball_x, baseball_y, 50, 50)  # Initial size of the baseball

running = True

# Clock
clock = pygame.time.Clock()
last_update_time = pygame.time.get_ticks()

while running:
    timer.tick(fps)
    screen.fill(blue)

    # Sun
    sun = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation\sun.png'), (150,150))
    screen.blit(sun, (sun_x, sun_y))

    # field
    floor = pygame.draw.rect(screen, dark_green, [0, 350, WIDTH, HEIGHT - 300])
    homeplate = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation\homeplate.png'), (150, 150))
    screen.blit(homeplate, (homeplate_x, homeplate_y))

    # BatterBox
    batterbox1 = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation/batterbox.png'), (250,200))
    screen.blit(batterbox1, (batterbox1_x, batterbox1_y))
    
    batterbox2 = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation/batterbox.png'), (250,200))
    screen.blit(batterbox2, (batterbox2_x, batterbox2_y))

    # Drawing of the throw button
    pygame.draw.rect(screen, throw_button_color, throw_button_rect)
    text_surface = font.render(throw_button_text, True, white)
    text_rect = text_surface.get_rect(center=throw_button_rect.center)
    screen.blit(text_surface, text_rect)

    # players on screen
    screen.blit(actual_swing[current_image_index], (player1_x, player1_y-10))
    screen.blit(pitcher_throw[pitcher_current_image_index], (player2_x, player2_y-22))

    # Reset baseball position if it has been thrown or hit
    if ball_thrown or hit:
        # Reset baseball's position back to the pitcher's hand
        baseball_x = 445  
        baseball_y = 240  
        baseball_scale = 1.0  
        pitching = False  # Stop pitching
        ball_thrown = False  # Reset the thrown state
        hit = False  # Reset hit state

    # Draw the batter's rectangle for debugging
    # pygame.draw.rect(screen, (255, 0, 0), batter_rect, 2)
    hit_box_x = 424
    hit_box_y = 390
    
    batter_rect.x = hit_box_x
    batter_rect.y = hit_box_y

    # Baseball rectangle
    baseball_rect.topleft = (baseball_x, baseball_y)

    contact_point_x = 475
    contact_point_y = 440

    bat_rect = pygame.Rect(batter_rect.centerx - 50, batter_rect.centery - 46, 100, 120)  # Adjust dimensions as needed

    # Changing game state

    # pygame.draw.circle(screen, (255, 0, 0), (contact_point_x, contact_point_y), 5)  # Draw contact point

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                if throw_button_rect.collidepoint(event.pos):
                    if pitcher_animation_complete == True:
                        pitching = True  # Start pitching when throw button is clicked

                pitcher_animation_running = True
                pitcher_current_image_index = 0
                pitcher_last_update_time = pygame.time.get_ticks()
                
                batter_rect.x = event.pos[0] - (batter_rect.width // 2)
                batter_rect.y = event.pos[1] - batter_rect.height

                    
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not animation_running:  # Check if spacebar is pressed
                print("Batter Swung!")
                animation_running = True
                current_image_index = 0
                animation_complete = False

                # Define the contact point (e.g., bottom center of the batter's rectangle)
                bat_rect = pygame.Rect(batter_rect.centerx - 50, batter_rect.centery - 46, 100, 120)
                
                # Check for collison only when the spacebar is pressed
            if event.key == pygame.K_SPACE and bat_rect.colliderect(baseball_rect):
                print("Baseball Hit!")  # Logic for hitting the ball
                hit = True
                scaling_start_time = pygame.time.get_ticks()  # Start scaling
                is_scaling = True  # Set scaling flag

    # Handle scaling logic
    if is_scaling:
        current_time = pygame.time.get_ticks()
        elapsed_time = current_time - scaling_start_time

        if elapsed_time < scaling_duration:
            # Scale up
            scale_factor = 1 + 0.5 * (elapsed_time / scaling_duration)  # Scale to 1.5x
        elif elapsed_time < scaling_duration * 2:
            # Scale down
            scale_factor = 1.5 - 0.5 * ((elapsed_time - scaling_duration) / scaling_duration)
        else:
            is_scaling = False  # Reset scaling
            scale_factor = 1.0  # Reset to original size

    # Update the baseball rectangle position
    baseball_rect.topleft = (baseball_x, baseball_y)

    # pygame.draw.rect(screen, (255, 0, 0), bat_rect, 2)  # Bat rectangle
    # pygame.draw.rect(screen, (0, 0, 255), baseball_rect, 2)  # Baseball rectangle

    if ball_thrown and batter_rect.colliderect(baseball_rect):
        print("Contact made!")
        hit = True

    if pitcher_animation_running:
        current_time = pygame.time.get_ticks()
        if current_time - pitcher_last_update_time >= pitcher_animation_speed:
            pitcher_current_image_index += 1
            pitcher_last_update_time = current_time

            if pitcher_current_image_index >= len(pitcher_throw):
                pitcher_current_image_index = len(pitcher_throw) - 1  # Loop back or stop
                pitcher_animation_running = False  # Stop the animation

                # Now that the animation is done, start pitching the ball
                pitching = True

    if pitching:
        if baseball_y < homeplate_y + 75:  # Move towards the plate
            baseball_y += 5  # Adjust speed here
            baseball_scale += 0.01  # Slightly increase size
            ball_positions.append((baseball_x, baseball_y))
        else:
            ball_thrown = True  # Mark that the ball has been thrown
            last_pitch_time = pygame.time.get_ticks()   

    # Updated position and scale (Baseball)
    baseball = pygame.transform.scale(pygame.image.load('Capstone File\Player_Animation/baseball_frame_1.png'), (int(50 * baseball_scale), int(50 * baseball_scale)))
    if pitching == True: 
        screen.blit(baseball, (baseball_x, baseball_y))

    # Reset baseball position if it has been thrown or hit
    if ball_thrown or hit:
        # Reset baseball's position back to the pitcher's hand
        baseball_x = 445  
        baseball_y = 240  
        baseball_scale = 1.0  
        pitching = False  # Stop pitching
        ball_thrown = False  # Reset the thrown state
        hit = False  # Reset hit state

    if ball_thrown and not hit:
        if len(ball_positions) > 0 and pygame.time.get_ticks() - last_pitch_time > 2000:  # 2 seconds
            ball_positions.clear()  # Clear positions after 2 seconds

    # Batter animation
    if animation_running:
        current_time = pygame.time.get_ticks()
        if current_time - last_update_time >= animation_speed:
            current_image_index += 1
            last_update_time = current_time

            if current_image_index >= len(actual_swing):
                current_image_index = len(actual_swing) - 1
                animation_running = False
                animation_complete = True               
    # Draw the minimap
    draw_minimap(screen, minimap_image, baseball_image, scale_factor)

    pygame.display.flip()

pygame.quit()
