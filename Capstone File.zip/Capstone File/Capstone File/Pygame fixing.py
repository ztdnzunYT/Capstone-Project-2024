import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 550
MINIMAP_WIDTH, MINIMAP_HEIGHT = 200, 150
FPS = 60

# Colors
WHITE = (255, 255, 255)

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# Load your minimap image
minimap_image = pygame.image.load("Capstone File\Player_Animation\Top-Down-Field-View.png")
minimap_image = pygame.transform.scale(minimap_image, (MINIMAP_WIDTH, MINIMAP_HEIGHT))


def draw_minimap(screen, minimap_image):
    # Draw the minimap image
    screen.blit(minimap_image, (SCREEN_WIDTH - MINIMAP_WIDTH - 10, 60))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Draw the minimap
    draw_minimap(screen, minimap_image)

    # Update the display
    pygame.display.flip()
    clock.tick(FPS)