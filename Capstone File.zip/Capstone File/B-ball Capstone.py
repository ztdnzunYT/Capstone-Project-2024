import random

import pygame

WIDTH = 1000
HEIGHT = 600
brown = (150, 65, 0)
dark_green = (6, 64, 43)
white = (255, 255, 255)
blue = (173, 216, 230)
fps = 60
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption("B-ball")
timer = pygame.time.Clock()
player1_x = 20
player1_y = 230
player2_x = 450
player2_y = 235


running = True
while running:
    timer.tick(fps)
    screen.fill(blue)
    floor = pygame.draw.rect(screen, dark_green, [0, 350, WIDTH, HEIGHT - 300])
    floor_line = pygame.draw.line(screen, white, (0, 350), (WIDTH, 350), 5)

    player1 = pygame.transform.scale(pygame.image.load('Player_Animation/Stance.png'), (350,350))
    screen.blit(player1, (player1_x, player1_y))

    player2 = pygame.transform.scale(pygame.image.load('Player_Animation/pitcher_stance2.png'), (150,150))
    screen.blit(player2, (player2_x, player2_y))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()
pygame.quit()
