import random

import pygame

WIDTH = 1000
HEIGHT = 600
brown = (150, 65, 0)
dark_green = (6, 64, 43)
white = (255, 255, 255)
fps = 60
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption("B-ball")
timer = pygame.time.Clock()

running = True
while running:
    timer.tick(fps)
    screen.fill(dark_green)
    floor = pygame.draw.rect(screen, brown, [0, 350, WIDTH, HEIGHT - 300])
    floor_line = pygame.draw.line(screen, white, (0, 350), (WIDTH, 350), 5)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()
pygame.quit()
