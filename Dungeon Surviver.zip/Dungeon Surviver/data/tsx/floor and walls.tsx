<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="floor and walls" tilewidth="32" tileheight="32" tilecount="63" columns="9">
 <image source="../../dungeon tileset 2/Tiles-SandstoneDungeons.png" width="288" height="224"/>
 <tile id="1" probability="0.025"/>
 <tile id="2" probability="0.975"/>
</tileset>
