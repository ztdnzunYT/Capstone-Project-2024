import random

import pygame
import pathlib
import os 
import time
WIDTH = 1000
HEIGHT = 600
brown = (150, 65, 0)
dark_green = (6, 64, 43)
white = (255, 255, 255)
blue = (173, 216, 230)
fps = 60
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption("B-ball")
timer = pygame.time.Clock()
player1_x = 120
player1_y = 300
player2_x = 450
player2_y = 235
batterbox1_x = 230
batterbox1_y = 420
homeplate_x = 400
homeplate_y = 420
batterbox2_x = 478
batterbox2_y = 420
sun_x = 850
sun_y = -10


mouse_down = False
# Batter
anim = 0
delay_time = 0
anim2 = 0
delay_time2 = 0

# Pitcher
pitcher_anim = 0
pitcher_delay_time = 0
pitcher_anim2 = 0
pitcher_delay_time2 = 0 

swing_animations = ["Player_Animation\Stance.png", "Player_Animation\Bend.png", "Player_Animation\Swing.png", "Player_Animation\Post_swing.png"]

pitch_animations = ["Player_Animation\pitcher_stance2.png", "Player_Animation\pitcher_arm_extend2.png", "Player_Animation\pitcher_release2.png"]


def Baseballswinganimation(anim_num):
    global mouse_down
    global anim
    
    global player1
    player1 = pygame.transform.scale(pygame.image.load(swing_animations[anim_num]),(350,350) )
    
    mouse_down = False
   
player1 = pygame.transform.scale(pygame.image.load('Player_Animation\Stance.png'), (350,350)) 


def Baseballpitcheranimation(pitcher_anim_num):
    global player2
    global pitcher_anim

    player2 = pygame.transform.scale(pygame.image.load(pitch_animations[pitcher_anim_num]), (150,150))

player2 = pygame.transform.scale(pygame.image.load('Player_Animation/pitcher_stance2.png'), (150,150))

running = True
while running:
    timer.tick(fps)
    screen.fill(blue)
    floor = pygame.draw.rect(screen, dark_green, [0, 350, WIDTH, HEIGHT - 300])
    floor_line = pygame.draw.line(screen, white, (0, 350), (WIDTH, 350), 5)
    homeplate = pygame.transform.scale(pygame.image.load('Player_Animation/homeplate.png'), (150,150))
    screen.blit(homeplate, (homeplate_x, homeplate_y))
    
    screen.blit(player1, (player1_x, player1_y))

    screen.blit(player2, (player2_x, player2_y))

    delay_time += 1
    if delay_time > 200 and mouse_down == False:
        if pygame.mouse.get_pressed()[0]:
            delay_time = 0

    delay_time2 += 1 

    if delay_time2 % 60 == 0:
        if anim < len(swing_animations):
            Baseballswinganimation(anim)
            anim +=1 
        else:
            anim = 0
    
    if delay_time == 0:
        anim = 0
        
        if pygame.mouse.get_pressed()[0]:
            mouse_down = True
            if mouse_down:
                Baseballswinganimation(anim)

    pitcher_delay_time += 1
    if pitcher_delay_time > 200:
        pitcher_delay_time = 0

    pitcher_delay_time2 += 1

    if pitcher_delay_time2 % 35 == 0:
        if pitcher_anim < len(pitch_animations):
            Baseballpitcheranimation(pitcher_anim)
            pitcher_anim += 1
        else:
            pitcher_anim = 0

    if pitcher_delay_time == 0:
        anim = 0

        
    

    #player2 = pygame.transform.scale(pygame.image.load('Player_Animation/pitcher_stance2.png'), (150,150))
    #screen.blit(player2, (player2_x, player2_y))

    batterbox1 = pygame.transform.scale(pygame.image.load('Player_Animation/batterbox.png'), (250,200))
    screen.blit(batterbox1, (batterbox1_x, batterbox1_y))

    batterbox2 = pygame.transform.scale(pygame.image.load('Player_Animation/batterbox.png'), (250,200))
    screen.blit(batterbox2, (batterbox2_x, batterbox2_y))

    sun = pygame.transform.scale(pygame.image.load('Player_Animation/sun.png'), (150,150))
    screen.blit(sun, (sun_x, sun_y))



    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()
pygame.quit()
