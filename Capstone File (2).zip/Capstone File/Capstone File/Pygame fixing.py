import pygame
import sys

# DO NOT CHANGE
WIDTH = 1000
HEIGHT = 600
brown = (150, 65, 0)
dark_green = (6, 64, 43)
white = (255, 255, 255)
blue = (173, 216, 230)
fps = 60

# Pygame window
pygame.init()
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption("B-ball")
timer = pygame.time.Clock()

# The Pitch Button 
throw_button_color = (0, 128, 0)  # Green color for throw button
throw_button_rect = pygame.Rect(800, 500, 150, 50)  # Position and size of the throw button
throw_button_text = "Throw Pitch"
font = pygame.font.Font(None, 36)

# Initial player and baseball positions
player1_x = 120
player1_y = 300
player2_x = 450
player2_y = 238
homeplate_x = 400
homeplate_y = 420
batterbox1_x = 230
batterbox1_y = 420
batterbox2_x = 478
batterbox2_y = 420
sun_x = 850
sun_y = -10

# Initialize Pygame
pygame.init()

# Initial images
batter1 = pygame.transform.scale(pygame.image.load('Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\Stance.png'), (350, 350))
pitcher1 = pygame.transform.scale(pygame.image.load('Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\pitcher_stance2.png'), (150, 150))
# Sun
sun = pygame.transform.scale(pygame.image.load('Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\sun.png'), (150,150))
screen.blit(sun, (sun_x, sun_y))

# field
floor = pygame.draw.rect(screen, dark_green, [0, 350, WIDTH, HEIGHT - 300])
homeplate = pygame.transform.scale(pygame.image.load('Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\homeplate.png'), (150, 150))
screen.blit(homeplate, (homeplate_x, homeplate_y))
    
# players on screen
screen.blit(batter1, (player1_x, player1_y))
screen.blit(pitcher1, (player2_x, player2_y))

#BatterBox
batterbox1 = pygame.transform.scale(pygame.image.load('Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation/batterbox.png'), (250,200))
screen.blit(batterbox1, (batterbox1_x, batterbox1_y))
    
batterbox2 = pygame.transform.scale(pygame.image.load('Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation/batterbox.png'), (250,200))
screen.blit(batterbox2, (batterbox2_x, batterbox2_y))

# Drawing of the throw button
pygame.draw.rect(screen, throw_button_color, throw_button_rect)
text_surface = font.render(throw_button_text, True, white)
text_rect = text_surface.get_rect(center=throw_button_rect.center)
screen.blit(text_surface, text_rect)



# Load images
batter_image_filenames = ['Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\Stance.png', 'Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\Bend.png', 'Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\Swing.png', 'Pygame Testing Folder\Capstone File Updated Swing\Capstone File\Capstone File\Player_Animation\Post_swing.png']  # Add your image paths
batter_images = [pygame.image.load(filename) for filename in batter_image_filenames]
current_image_index = 0
animation_running = False
animation_complete = False
animation_speed = 350  # milliseconds

# Main loop
clock = pygame.time.Clock()
last_update_time = pygame.time.get_ticks()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not animation_running:
                animation_running = True
                current_image_index = 0  # Reset to first image
                animation_complete = False

    # Clear the screen
    #screen.fill((255, 255, 255))

    # Update and draw the current image if the animation is running
    if animation_running:
        current_time = pygame.time.get_ticks()
        if current_time - last_update_time >= animation_speed:
            current_image_index += 1
            last_update_time = current_time

            # Check if the animation is complete
            if current_image_index >= len(batter_images):
                current_image_index = len(batter_images) - 1  # Keep on the last image
                animation_running = False  # Stop the animation
                animation_complete = True
        
        # Draw the current image
        screen.blit(batter_images[current_image_index], (WIDTH // 2 - batter_images[current_image_index].get_width() // 2,
                                                   HEIGHT // 2 - batter_images[current_image_index].get_height() // 2))

    # Update the display
    pygame.display.flip()
    clock.tick(60)  # Maintain 60 frames per second
